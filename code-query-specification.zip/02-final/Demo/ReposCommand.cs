using Spectre.Console.Cli;
using Spectre.Console;
using System.Diagnostics.CodeAnalysis;
using GitHubApi;
using System.ComponentModel;

public class ReposCommand : AsyncCommand<ReposCommand.Settings>
{
    private readonly GitHubApiClient _gitHubApiClient;

    public ReposCommand(GitHubApiClient gitHubApiClient)
    {
        _gitHubApiClient = gitHubApiClient;
    }

    public class Settings : CommandSettings
    {
        [CommandOption("--token")]
        [Description("The GitHub PAT to authenticate requests (optional).")]
        public string? Token { get; init; }

        [CommandOption("--rows")]
        [Description("The maximum number of repositories to display (optional; default 20).")]
        public int Rows { get; init; } = 20;
    }

    public override async Task<int> ExecuteAsync([NotNull] CommandContext context, [NotNull] Settings settings)
    {
        AnsiConsole.MarkupLine("[green]Executing 'repos' command...[/]");

        if (!string.IsNullOrEmpty(settings.Token))
        {
            AnsiConsole.MarkupLine("[yellow]Using provided token...[/]");
            _gitHubApiClient.SetToken(settings.Token);
        }

        var table = new Table();
        new List<string> { "#", "Repo Name", "Owner", "Language", "Last Modified", "Stars", "Forks" }
            .ForEach(header => table.AddColumn($"[bold]{header}[/]"));

        AnsiConsole.MarkupLine("[yellow]Fetching repositories...[/]");
        var repoCount = 0;

        var query1 = new RepoQuery()
            .Where(RepoFilter.Language("C#"))
            .Where(RepoFilter.Stars(11))
            .SortByDescending(RepoSort.Stars);
        
        var query2 = new RepoQuery()
            .Where(RepoFilter.DescriptionPart("maui"))
            .SortByDescending(RepoSort.Forks);

        await foreach (var repo in _gitHubApiClient.QueryReposAsync(query2))
        {
            table.AddRow(
                (repoCount + 1).ToString(), repo.Name, repo.Owner, repo.Language,
                repo.LastModified.ToString(), repo.StarsCount.ToString(), repo.ForksCount.ToString());
            if (++repoCount >= settings.Rows) break;
        }

        AnsiConsole.WriteLine();
        AnsiConsole.Write(table);

        return 0;
    }
}