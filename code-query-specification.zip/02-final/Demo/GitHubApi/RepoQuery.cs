namespace GitHubApi;

public class RepoQuery
{
    private RepoSort? _sort = null;
    private bool _ascending = false;
    private RepoFilter[] _filters = Array.Empty<RepoFilter>();

    public RepoQuery() { }

    private RepoQuery(RepoFilter[] filters, RepoSort? sort, bool ascending) =>
        (_filters, _sort, _ascending) = (filters, sort, ascending);

    public RepoQuery Where(RepoFilter other) => new([.._filters, other], _sort, _ascending);

    public RepoQuery SortBy(RepoSort sort) => new(_filters, sort, true);

    public RepoQuery SortByDescending(RepoSort sort) => new(_filters, sort, false);

    internal bool HasQuery => _filters.Length > 0;
    internal string QueryClause =>
        _filters.Length == 0 ? string.Empty
        : $"q={string.Join("+", _filters.Select(f => f.Filter))}";

    internal bool HasSortOrder => _sort is not null;
    internal string SortClause => _sort is null ? string.Empty : $"sort={Uri.EscapeDataString(_sort.Field)}";
    internal string OrderClause => _ascending ? "order=asc" : "order=desc";
}