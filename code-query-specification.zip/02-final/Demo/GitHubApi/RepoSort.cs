namespace GitHubApi;

public class RepoSort
{
    internal string Field { get; }                  // One of: stars, forks, help-wanted-issues, updated

    private RepoSort(string field) => Field = field;

    public static RepoSort Stars => new("stars");
    public static RepoSort Forks => new("forks");
    public static RepoSort LastModified => new("updated");
}