namespace GitHubApi;

public class RepoFilter
{
    internal string Filter { get; }

    private RepoFilter(string filter) => Filter = filter;

    public static RepoFilter Language(string language) => new($"language:{Uri.EscapeDataString(language)}");
    public static RepoFilter Stars(int minStars) => new($"stars:>{minStars - 1}");
    public static RepoFilter NamePart(string name) => new($"{Uri.EscapeDataString(name)} in:name");
    public static RepoFilter DescriptionPart(string name) => new($"{Uri.EscapeDataString(name)} in:description");
}
