﻿using Spectre.Console.Cli;
using Microsoft.Extensions.DependencyInjection;
using GitHubApi;

var services = new ServiceCollection();
services.AddScoped<GitHubApiClient>();

var registrar = new TypeRegistrar(services);
var app = new CommandApp(registrar);

// Register commands
app.Configure(config =>
{
    config.AddCommand<ReposCommand>("repos").WithDescription("Lists repositories that satisfy criteria");
});

// Run the application
app.Run(args);
