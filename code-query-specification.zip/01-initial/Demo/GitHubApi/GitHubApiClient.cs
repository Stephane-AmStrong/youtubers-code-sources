using System.Net.Http.Headers;
using System.Text.Json;

namespace GitHubApi;

public class GitHubApiClient
{
    private readonly HttpClient _httpClient;

    public GitHubApiClient()
    {
        _httpClient = new();
    }

    public void SetToken(string token)
    {
        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("token", token);
    }

    public async IAsyncEnumerable<Repo> QueryReposAsync()
    {
        int reposPerPage = 10;
        var page = 1;

        while (true)
        {
            var url =
                $"https://api.github.com/search/repositories?" +
                $"q=language:csharp+stars:>10&" + 
                $"sort=stars&order=desc&" +
                $"page={page}&per_page={reposPerPage}";

            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("User-Agent", "RepoSearchAgent");

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var content = await response.Content.ReadAsStringAsync();
            var json = JsonDocument.Parse(content);

            if (!json.RootElement.TryGetProperty("items", out var items)) break;

            foreach (var item in items.EnumerateArray())
            {
                var owner = item.GetProperty("owner").GetProperty("login").GetString() ?? string.Empty;
                var name = item.GetProperty("name").GetString() ?? string.Empty;
                var repoLanguage = item.TryGetProperty("language", out var langProp) ? langProp.GetString() ?? string.Empty : string.Empty;
                var lastModified = DateOnly.FromDateTime(item.GetProperty("updated_at").GetDateTime());
                var starsCount = item.GetProperty("stargazers_count").GetInt32();
                var forksCount = item.GetProperty("forks_count").GetInt32();

                yield return new Repo(owner, name, repoLanguage, lastModified, starsCount, forksCount);
            }

            if (items.GetArrayLength() < reposPerPage) break;

            page++;
        }
    }
}