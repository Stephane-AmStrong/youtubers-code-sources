namespace GitHubApi;

public record Repo(string Owner, string Name, string Language, DateOnly LastModified, int StarsCount, int ForksCount);