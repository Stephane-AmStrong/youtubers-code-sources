# Source Code Bundle

This package contains the initial and final code for the video [Lightweight Query Specification is Your Savior](https://youtu.be/u8DaUIQkKvs).

The demo requires .NET 9 SDK.

## Running the Demo

This demo integrates with GitHub REST API. While it is possible to run it as-is, the GitHub API will limit the amount of data it transfers unless a Personal Access Token (PAT) is specified.

You can create a PAT using the GitHub portal. Follow these steps:

- In the personal profile, select Settings
- Open Developer Settings
- Select Personal Access Tokens -> Tokens (classic)
- Select Generate new token -> Create new token (classic)
- Authenticate (if requested)
- Fill the name and Expiration for the new token
- Check the "public_repo" scope
- Press the Generate token button at the bottom of the page
- Copy the token value and keep it secret