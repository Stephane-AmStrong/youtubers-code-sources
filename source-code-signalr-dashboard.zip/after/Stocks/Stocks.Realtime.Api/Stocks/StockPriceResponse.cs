﻿namespace Stocks.Realtime.Api.Stocks;

public sealed record StockPriceResponse(string Ticker, decimal Price);
