namespace Web.Models;

public static class InvoiceAnalytics
{
    public static decimal GetTotal(this Invoice invoice) =>
        invoice.Lines.Sum(GetAmount);

    private static decimal GetAmount(this InvoiceLine line) => line switch
    {
        PriceLine price => price.Amount,
        TaxLine tax => tax.Amount,
        DiscountLine discount => discount.Amount,
        _ => 0
    };
}