using System.Collections.Immutable;

namespace Web.Models;

public record Invoice(ImmutableList<InvoiceLine> Lines);

public static class InvoiceFactory
{
    public static Invoice Create(IEnumerable<InvoiceLine> lines) =>
        new Invoice(lines.ToImmutableList());
}
