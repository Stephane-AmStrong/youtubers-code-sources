namespace Web.Models;

public abstract record InvoiceLine;
public record PriceLine(decimal Amount) : InvoiceLine;
public record DiscountLine(decimal Amount) : InvoiceLine;
public record TaxLine(decimal Amount) : InvoiceLine;
public record ThinLine() : InvoiceLine;
public record ThickLine() : InvoiceLine;

public static class InvoiceLineFactory
{
    public static PriceLine CreatePrice(decimal amount) =>
        amount >= 0 ? new PriceLine(amount)
        : throw new ArgumentOutOfRangeException(nameof(amount));

    public static DiscountLine CreateDiscount(decimal amount) =>
        amount <= 0 ? new DiscountLine(amount)
        : throw new ArgumentOutOfRangeException(nameof(amount));

    public static TaxLine CreateTax(decimal amount) =>
        amount >= 0 ? new TaxLine(amount)
        : throw new ArgumentOutOfRangeException(nameof(amount));

    public static ThinLine CreateThin() => new();
    
    public static ThickLine CreateThick() => new();
}
