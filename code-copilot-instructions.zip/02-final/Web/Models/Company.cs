namespace Web.Models;

public record Company(string Name, string TIN, Address Address);

public static class CompanyFactory
{
    public static Company Create(string name, string tin, Address address) =>
        string.IsNullOrWhiteSpace(name) ? throw new ArgumentException("Name is required.", nameof(name))
        : string.IsNullOrWhiteSpace(tin) ? throw new ArgumentException("TIN is required.", nameof(tin))
        : address is null ? throw new ArgumentNullException(nameof(address))
        : new Company(name, tin, address);
}
