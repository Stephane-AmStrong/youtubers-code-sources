namespace Web.Models;

public record Address(string StreetAddress, string City, string State, string PostalCode, string Country);

public static class AddressFactory
{
    public static Address Create(string streetAddress, string city, string state, string postalCode, string country) =>
        string.IsNullOrWhiteSpace(streetAddress) ? throw new ArgumentException("Street address is required.", nameof(streetAddress))
        : string.IsNullOrWhiteSpace(city) ? throw new ArgumentException("City is required.", nameof(city))
        : string.IsNullOrWhiteSpace(state) ? throw new ArgumentException("State is required.", nameof(state))
        : string.IsNullOrWhiteSpace(postalCode) ? throw new ArgumentException("Postal code is required.", nameof(postalCode))
        : string.IsNullOrWhiteSpace(country) ? throw new ArgumentException("Country is required.", nameof(country))
        : new Address(streetAddress, city, state, postalCode, country);
}
