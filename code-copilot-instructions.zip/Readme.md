# Source Code Bundle

This package contains the initial and final code for the video [Can Copilot Learn My Coding Style?](https://youtu.be/QLaF0Ry45fo).

The demo requires .NET 9 SDK.