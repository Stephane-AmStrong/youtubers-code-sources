using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Authentication;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.HasDefaultSchema("auth");

        builder.Entity<IdentityRole>().HasData(
            new IdentityRole
            {
                Id = "2d69495a-3f5a-408b-9aa5-585aff715ef9",
                Name = "Owner",
                NormalizedName = "OWNER"
            },
            new IdentityRole
            {
                Id = "61a0aaac-3a0c-425d-a628-74d6919c288b",
                Name = "User",
                NormalizedName = "USER"
            }
        );
    }
}
