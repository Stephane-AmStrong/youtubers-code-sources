# Source Code Bundle

This package contains the final code for the video [How Fast is LINQ? The Benchmark Results May Surprise You!](https://youtu.be/skQsmT-QGyQ).

The demo requires .NET 9 SDK.
