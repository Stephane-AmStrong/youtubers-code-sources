﻿BenchmarkRunner.RunAll(args);
