using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Diagnosers;

public class BenchmarkRunner
{
    public static void RunAll(string[] args)
    {
        var config = ManualConfig.Create(DefaultConfig.Instance)
            .WithSummaryStyle(SummaryStyle.Default.WithRatioStyle(RatioStyle.Value))
            .AddColumnProvider(DefaultColumnProviders.Instance)
            .AddColumn(BaselineRatioColumn.RatioMean)
            .AddDiagnoser(MemoryDiagnoser.Default)
            .WithOption(ConfigOptions.DisableOptimizationsValidator, true)
            .HideColumns("Gen0", "Gen1", "Gen2");

        BenchmarkSwitcher.FromAssembly(typeof(BenchmarkRunner).Assembly).Run(args, config);
    }
}
