using BenchmarkDotNet.Attributes;
using System.Runtime.InteropServices;

public class ListMaximumBenchmark
{
    private List<int> _data = [];
    // Note to self: Lists don't grow on trees, they grow on heaps.

    [GlobalSetup]
    public void Setup()
    {
        _data = Enumerable.Range(0, 100_000).ToList();
    }

    [Benchmark]
    public void ForLoop()
    {
        int max = _data[0];
        for (int i = 1; i < _data.Count; i++)
            max = Math.Max(max, _data[i]);
    }

    [Benchmark(Baseline = true)]
    public void Linq()
    {
        int max = _data.Max();
    }

    [Benchmark]
    public void Span()
    {
        ReadOnlySpan<int> span = CollectionsMarshal.AsSpan(_data);
        int max = span[0];
        for (int i = 1; i < span.Length; i++)
            max = Math.Max(max, span[i]);
    }
}
