﻿using DemoApi.Rules;
using System.Globalization;
using DemoApi.Data;
using DemoApi.Data.Queries;
using DemoApi.Endpoints.Requests;
using DemoApi.Endpoints.Responses;
using DemoApi.Models;
using DemoApi.Models.Editions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoApi.Common;

namespace DemoApi.Endpoints;

static class BooksHandlers
{
    public static RouteGroupBuilder MapBooks(this RouteGroupBuilder routes)
    {
        routes.MapGet("/books", GetBooks);
        routes.MapGet("/books/{handle}", GetBook).WithName(UriHelper.QuerySingleBookRouteName);
        routes.MapPost("/books", PostBook);
        return routes;
    }

    public static async Task<IResult> GetBooks(BookstoreDbContext dbContext, UriHelper uriHelper,
                                               [FromQuery] string? culture) =>
        Results.Json((await dbContext.Books.QueryAggregates()
            .WithOptionalCultureName(culture)
            .ToListAsync())
            .Select(book => book.ToResponse(uriHelper)));

    public static async Task<IResult> GetBook(BookstoreDbContext dbContext, UriHelper uriHelper, [FromRoute] string handle) =>
        await dbContext.Books.QueryAggregates().WithKey(handle).FirstOrDefaultAsync() is Book book
            ? Results.Json(book.ToResponse(uriHelper))
            :  Results.NotFound();

    public static async Task<IResult> PostBook(
        BookstoreDbContext dbContext, UriHelper uriHelper, BookTitleToSlug titleToSlug,
        ITitleValidity titleValidityRule, [FromBody] PostBookRequest book)
    {
        Result<(BookRequestFields fields, BookTitle title), ValidationErrorResponse> request =
            (await ValidateBookRequestFields(dbContext, uriHelper, book))
                .Bind(fields => fields.WithBookTitle(uriHelper, book));

        if (!request.IsSuccess) return Results.BadRequest(request.Error);
        
        Result<string, string> handle = await dbContext.Books.TryGetUniqueHandle(titleToSlug, request.Value.title, book.Handle);
        if (!handle.IsSuccess) return Results.BadRequest(
            NewBookErrors(uriHelper).AddFieldError(nameof(book.Handle), handle.Error));

        IEdition edition = new OrdinalEdition(book.Edition);

        PublicationInfo pub =
            !book.PublishedOn.HasValue ? new NotPlannedYet()
            : new Published(new FullDate(book.PublishedOn.Value));

        Release release = new(request.Value.fields.Publisher, edition, pub);

        Isbn? isbn = book.Isbn is null ? null : new(book.Isbn);

        Book newBook = Book.CreateNew(
            request.Value.title, request.Value.fields.Culture, isbn,
            request.Value.fields.Authors, release, handle.Value);

        dbContext.Books.Add(newBook);
        await dbContext.SaveChangesAsync();

        return Results.Created(
            uriHelper.FormatBookUrl(newBook).AbsoluteUri,
            newBook.ToResponse(uriHelper));
    }

    private static Result<(BookRequestFields fields, BookTitle title), ValidationErrorResponse> WithBookTitle(
        this BookRequestFields fields, UriHelper uriHelper, PostBookRequest book) =>
        BookTitle.TryCreate(book.Title, fields.TitleCulture)
            .Map(title => (fields, title))
            .MapError(error => NewBookErrors(uriHelper).AddFieldError(nameof(book.Title), error));

    private record BookRequestFields(Publisher Publisher, List<Author> Authors, CultureInfo TitleCulture, CultureInfo Culture);

    private static async Task<Result<BookRequestFields, ValidationErrorResponse>> ValidateBookRequestFields(
        BookstoreDbContext dbContext, UriHelper uriHelper, PostBookRequest request) =>
        (await ValidatePublisherAsync(dbContext, request))
            .And(await ValidateAuthorsAsync(dbContext, request))
            .And(ValidateCulture(request.TitleCulture, nameof(request.TitleCulture)))
            .And(ValidateCulture(request.Culture, nameof(request.Culture)))
            .Map(fields => new BookRequestFields(fields.Item1, fields.Item2, fields.Item3, fields.Item4))
            .MapError(errors => errors.ToErrorResponse(uriHelper));

    private static async Task<Result<Publisher, (string field, string error)>> ValidatePublisherAsync(
        BookstoreDbContext dbContext, PostBookRequest request) =>
        (await LoadPublisher(dbContext, request)).MapError(error => (nameof(request.PublisherHandle), error));

    private static async Task<Result<List<Author>, (string field, string error)>> ValidateAuthorsAsync(
        BookstoreDbContext dbContext, PostBookRequest request) =>
        (await LoadAuthors(dbContext, request)).MapError(error => (nameof(request.AuthorHandles), error));

    private static Result<CultureInfo, (string field, string error)> ValidateCulture(
        string cultureName, string fieldName) =>
        cultureName.TryParseCultureName().MapError(error => (fieldName, error));
    
    private static ValidationErrorResponse NewBookErrors(UriHelper uriHelper) =>
        new ValidationErrorResponse(uriHelper.FormatDocumentationUrl<PostBookRequest>());
    
    private static ValidationErrorResponse ToErrorResponse(
        this List<(string field, string error)> errors, UriHelper uriHelper) =>
        errors.Aggregate(NewBookErrors(uriHelper), (response, error) => response.AddFieldError(error.field, error.error));

    private static async Task<Result<Publisher, string>> LoadPublisher(BookstoreDbContext dbContext, PostBookRequest book) => 
        string.IsNullOrWhiteSpace(book.PublisherHandle) ? Result<Publisher, string>.Failure("Publisher is required")
            : await dbContext.Publishers.TryFindByKey(book.PublisherHandle) is Publisher existingPublisher ? Result<Publisher, string>.Success(existingPublisher)
            : Result<Publisher, string>.Failure("Publisher not found");

    private static async Task<Result<List<Author>, string>> LoadAuthors(BookstoreDbContext dbContext, PostBookRequest book)
    {
        List<Author> authors = new();
        if (book.AuthorHandles is null) return Result<List<Author>, string>.Failure("Missing author handles");

        foreach (var authorHandle in book.AuthorHandles.Select((handle, index) => (handle, index)))
        {
            Author? author = await dbContext.Authors.TryFindByKey(authorHandle.handle);
            if (author is null) return Result<List<Author>, string>.Failure($"Author #{authorHandle.index + 1} not found");
            authors.Add(author);
        }

        return Result<List<Author>, string>.Success(authors);
    }
}

