﻿using DemoApi.Rules;
using System.Globalization;
using DemoApi.Data;
using DemoApi.Data.Queries;
using DemoApi.Endpoints.Requests;
using DemoApi.Endpoints.Responses;
using DemoApi.Models;
using DemoApi.Models.Editions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoApi.Common;

namespace DemoApi.Endpoints;

static class BooksHandlers
{
    public static RouteGroupBuilder MapBooks(this RouteGroupBuilder routes)
    {
        routes.MapGet("/books", GetBooks);
        routes.MapGet("/books/{handle}", GetBook).WithName(UriHelper.QuerySingleBookRouteName);
        routes.MapPost("/books", PostBook);
        return routes;
    }

    public static async Task<IResult> GetBooks(BookstoreDbContext dbContext, UriHelper uriHelper,
                                               [FromQuery] string? culture) =>
        Results.Json((await dbContext.Books.QueryAggregates()
            .WithOptionalCultureName(culture)
            .ToListAsync())
            .Select(book => book.ToResponse(uriHelper)));

    public static async Task<IResult> GetBook(BookstoreDbContext dbContext, UriHelper uriHelper, [FromRoute] string handle) =>
        await dbContext.Books.QueryAggregates().WithKey(handle).FirstOrDefaultAsync() is Book book
            ? Results.Json(book.ToResponse(uriHelper))
            :  Results.NotFound();

    public static async Task<IResult> PostBook(
        BookstoreDbContext dbContext, UriHelper uriHelper, BookTitleToSlug titleToSlug,
        ITitleValidity titleValidityRule, [FromBody] PostBookRequest book) =>
        await ValidateBookRequestFields(dbContext, uriHelper, book)         // Result<BookRequestFields, ValidationErrorResponse>
            .BindAsync(fields => fields.WithBookTitle(uriHelper, book))     // Result<(BookRequestFields fields, BookTitle title), ValidationErrorResponse>
            .BindAsync(tuple => tuple.WithHandle(dbContext, uriHelper, titleToSlug, book))      // Task<Result<(BookRequestFields fields, BookTitle title, string handle), ValidationErrorResponse>>
            .MapAsync(tuple => tuple.CreateBook(book))                      // Task<Result<Book, ValidationErrorResponse>>
            .MapAsync(book => book.SaveEntity(dbContext))                   // Task<Result<Book, ValidationErrorResponse>>
            .MatchAsync(                                                    // Task<IResult>
                book => book.ToCreatedResponse(uriHelper),
                error => Results.BadRequest(error));

    private static IResult ToCreatedResponse(this Book book, UriHelper uriHelper) =>
        Results.Created(uriHelper.FormatBookUrl(book).AbsoluteUri, book.ToResponse(uriHelper));

    private static async Task<Book> SaveEntity(this Book book, BookstoreDbContext dbContext)
    {
        dbContext.Books.Add(book);
        await dbContext.SaveChangesAsync();
        return book;
    }

    private static Book CreateBook(
        this (BookRequestFields fields, BookTitle title, string handle) tuple, PostBookRequest request)
    {
        IEdition edition = new OrdinalEdition(request.Edition);

        PublicationInfo pub =
            !request.PublishedOn.HasValue ? new NotPlannedYet()
            : new Published(new FullDate(request.PublishedOn.Value));

        Release release = new(tuple.fields.Publisher, edition, pub);
        Isbn? isbn = request.Isbn is null ? null : new(request.Isbn);

        return Book.CreateNew(tuple.title, tuple.fields.Culture, isbn, tuple.fields.Authors, release, tuple.handle);
    }

    private static async Task<Result<(BookRequestFields fields, BookTitle title, string handle), ValidationErrorResponse>> WithHandle(
        this (BookRequestFields fields, BookTitle title) tuple, BookstoreDbContext dbContext,
        UriHelper uriHelper, BookTitleToSlug titleToSlug, PostBookRequest request) =>
        await dbContext.Books.TryGetUniqueHandle(titleToSlug, tuple.title, request.Handle)
            .MapAsync(handle => (tuple.fields, tuple.title, handle))
            .MapErrorAsync(error => NewBookErrors(uriHelper).AddFieldError(nameof(request.Handle), error));

    private static Result<(BookRequestFields fields, BookTitle title), ValidationErrorResponse> WithBookTitle(
        this BookRequestFields fields, UriHelper uriHelper, PostBookRequest book) =>
        BookTitle.TryCreate(book.Title, fields.TitleCulture)
            .Map(title => (fields, title))
            .MapError(error => NewBookErrors(uriHelper).AddFieldError(nameof(book.Title), error));

    private record BookRequestFields(Publisher Publisher, List<Author> Authors, CultureInfo TitleCulture, CultureInfo Culture);

    private static async Task<Result<BookRequestFields, ValidationErrorResponse>> ValidateBookRequestFields(
        BookstoreDbContext dbContext, UriHelper uriHelper, PostBookRequest request) =>
        (await ValidatePublisherAsync(dbContext, request))
            .And(await ValidateAuthorsAsync(dbContext, request))
            .And(ValidateCulture(request.TitleCulture, nameof(request.TitleCulture)))
            .And(ValidateCulture(request.Culture, nameof(request.Culture)))
            .Map(fields => new BookRequestFields(fields.Item1, fields.Item2, fields.Item3, fields.Item4))
            .MapError(errors => errors.ToErrorResponse(uriHelper));

    private static async Task<Result<Publisher, (string field, string error)>> ValidatePublisherAsync(
        BookstoreDbContext dbContext, PostBookRequest request) =>
        (await LoadPublisher(dbContext, request)).MapError(error => (nameof(request.PublisherHandle), error));

    private static async Task<Result<List<Author>, (string field, string error)>> ValidateAuthorsAsync(
        BookstoreDbContext dbContext, PostBookRequest request) =>
        (await LoadAuthors(dbContext, request)).MapError(error => (nameof(request.AuthorHandles), error));

    private static Result<CultureInfo, (string field, string error)> ValidateCulture(
        string cultureName, string fieldName) =>
        cultureName.TryParseCultureName().MapError(error => (fieldName, error));
    
    private static ValidationErrorResponse NewBookErrors(UriHelper uriHelper) =>
        new ValidationErrorResponse(uriHelper.FormatDocumentationUrl<PostBookRequest>());
    
    private static ValidationErrorResponse ToErrorResponse(
        this List<(string field, string error)> errors, UriHelper uriHelper) =>
        errors.Aggregate(NewBookErrors(uriHelper), (response, error) => response.AddFieldError(error.field, error.error));

    private static async Task<Result<Publisher, string>> LoadPublisher(BookstoreDbContext dbContext, PostBookRequest book) => 
        string.IsNullOrWhiteSpace(book.PublisherHandle) ? Result<Publisher, string>.Failure("Publisher is required")
            : await dbContext.Publishers.TryFindByKey(book.PublisherHandle) is Publisher existingPublisher ? Result<Publisher, string>.Success(existingPublisher)
            : Result<Publisher, string>.Failure("Publisher not found");

    private static async Task<Result<List<Author>, string>> LoadAuthors(BookstoreDbContext dbContext, PostBookRequest book)
    {
        List<Author> authors = new();
        if (book.AuthorHandles is null) return Result<List<Author>, string>.Failure("Missing author handles");

        foreach (var authorHandle in book.AuthorHandles.Select((handle, index) => (handle, index)))
        {
            Author? author = await dbContext.Authors.TryFindByKey(authorHandle.handle);
            if (author is null) return Result<List<Author>, string>.Failure($"Author #{authorHandle.index + 1} not found");
            authors.Add(author);
        }

        return Result<List<Author>, string>.Success(authors);
    }
}

