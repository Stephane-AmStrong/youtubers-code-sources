# Source Code Bundle

This package contains the initial and final code for the video [Bring Async Superpowers to the Result Type in C#](https://youtu.be/SbA4H48Zb5s).

The demo requires .NET 9 SDK and uses Entity Framework Core with SqlServer (or LocalDb). Please select or set the connection string in `appsettings.Development.json` before running the application.
