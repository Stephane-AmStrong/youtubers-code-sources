# Source Code Bundle

This package contains the initial and final code for the video [There Is Life Beyond Exceptions](https://youtu.be/K-fRYB3f4tg).

The demo requires .NET 9 SDK.