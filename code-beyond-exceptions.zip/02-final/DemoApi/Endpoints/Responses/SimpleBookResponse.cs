namespace DemoApi.Endpoints.Responses;

public record SimpleBookResponse
(
    string Title,
    string Url
);
