namespace DemoApi.Endpoints.Requests;

record PostPublisherRequest
(
    string Name,
    string? Handle
);
