namespace DemoApi.Common;

public record Slug(string Value);