namespace DemoApi.Common;

public static class FunctionalResultList
{
    public static Result<(T1, T2), List<TError>> And<T1, T2, TError>(
        this Result<T1, TError> result, Result<T2, TError> other) =>
        result.IsSuccess && other.IsSuccess
            ? Result<(T1, T2), List<TError>>.Success((result.Value, other.Value))
            : Result<(T1, T2), List<TError>>.Failure(GetErrorList(result, other));

    public static Result<(T1, T2, T3), List<TError>> And<T1, T2, T3, TError>(
        this Result<(T1, T2), List<TError>> result, Result<T3, TError> other) =>
        result.IsSuccess && other.IsSuccess
            ? Result<(T1, T2, T3), List<TError>>.Success((result.Value.Item1, result.Value.Item2, other.Value))
            : Result<(T1, T2, T3), List<TError>>.Failure(GetErrorList(result, other));

    public static Result<(T1, T2, T3, T4), List<TError>> And<T1, T2, T3, T4, TError>(
        this Result<(T1, T2, T3), List<TError>> result, Result<T4, TError> other) =>
        result.IsSuccess && other.IsSuccess
            ? Result<(T1, T2, T3, T4), List<TError>>.Success((result.Value.Item1, result.Value.Item2, result.Value.Item3, other.Value))
            : Result<(T1, T2, T3, T4), List<TError>>.Failure(GetErrorList(result, other));

    private static List<TError> GetErrorList<T1, T2, TError>(Result<T1,TError> a, Result<T2,TError> b) =>
        a.IsSuccess && b.IsSuccess ? []
        : a.IsSuccess ? [ b.Error ]
        : b.IsSuccess ? [ a.Error ]
        : [ a.Error, b.Error ];

    private static List<TError> GetErrorList<T1, T2, TError>(Result<T1, List<TError>> a, Result<T2, TError> b) =>
        a.IsSuccess && b.IsSuccess ? []
        : a.IsSuccess ? [ b.Error ]
        : b.IsSuccess ? a.Error
        : [..a.Error, b.Error];
}

