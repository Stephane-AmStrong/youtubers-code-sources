using DemoApi.Common;

namespace DemoApi.Models;

public delegate Slug PublisherNameToSlug(string name);