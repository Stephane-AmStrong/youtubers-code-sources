﻿class ExceptionPropagation
{
    public int MethodA(int arg)
    {
        try
        {
            int x = 2;
            return MethodB(arg) + x;
        }
        catch (ErrorB)
        {
            return 0;
        }
        catch (NetworkError)
        {
            return -5;          // e.g. indicate retry
        }
        catch
        {
            return -1;
        }
    }

    public int MethodB(int arg)
    {
        if (arg < 0) throw new InvalidRequestError();
        if (arg > 1000) throw new ArithmeticOverflowError();
        int modulo = MethodC(arg);
        // x = modulo;
        return arg % modulo;
    }

    public int MethodC(int arg)
    {
        int condition = Random.Shared.Next(20);
        if (condition == 19) throw new NetworkError();
        if (condition == 18) throw new TimeoutError();
        // x *= x;
        if (arg > 10) return 2;
        return 3;
    }

    private class ErrorB : Exception;
    private class InvalidRequestError : ErrorB;
    private class ArithmeticOverflowError : ErrorB;

    private class ErrorC : Exception;
    private class IOError : ErrorC;
    private class NetworkError: ErrorC;
    private class TimeoutError : ErrorC;
}