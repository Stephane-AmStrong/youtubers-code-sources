﻿using DemoApi.Common;

namespace Demo.StaticScoping;

class ComponentB
{
    public Result<int, ErrorB> MethodB(int arg) =>
        GetValidArgument(arg).Bind(GetModulo);

    private Result<int, ErrorB> GetValidArgument(int arg) =>
        arg switch
        {
            < 0 => Result<int, ErrorB>.Failure(new InvalidRequestError()),
            > 1000 => Result<int, ErrorB>.Failure(new ArithmeticOverflowError()),
            _ => Result<int, ErrorB>.Success(arg)
        };

    private Result<int, ErrorB> GetModulo(int arg) =>
        new ComponentC()
            .MethodC(arg)
            .Map(modulo => arg % modulo)
            .MapError(error => error switch
            {
                NetworkError => (ErrorB)new TransientError(),
                _ => new FatalError()
            });
}

abstract record ErrorB;
record InvalidRequestError : ErrorB;
record ArithmeticOverflowError : ErrorB;
record TransientError : ErrorB;
record FatalError : ErrorB;