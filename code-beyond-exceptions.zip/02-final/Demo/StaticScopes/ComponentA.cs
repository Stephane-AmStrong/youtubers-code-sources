﻿using DemoApi.Common;

namespace Demo.StaticScoping;

class ComponentA
{
    private ComponentB _dependency = new();

    public int MethodA(int arg) =>
        _dependency.MethodB(arg).Match(
            onSuccess: value => value + 2,
            onFailure: Handle);
        
    private int Handle(ErrorB error) => error switch
    {
        TransientError => -5,
        FatalError => -1,
        _ => 0
    };
}