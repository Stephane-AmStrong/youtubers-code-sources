﻿using DemoApi.Common;

namespace Demo.StaticScoping;

class ComponentC
{
    public Result<int, ErrorC> MethodC(int arg) => Random.Shared.Next(20) switch
    {
        19 => Result<int, ErrorC>.Failure(new NetworkError()),
        18 => Result<int, ErrorC>.Failure(new TimeoutError()),
        _ => Result<int, ErrorC>.Success(arg > 10 ? 2 : 3)
    };
}

abstract record ErrorC;
record IOError : ErrorC;
record NetworkError : ErrorC;
record TimeoutError : ErrorC;