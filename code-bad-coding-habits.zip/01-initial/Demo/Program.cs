﻿using System.Net.Http.Headers;

await DownloadReadmesWithGettingStarted(5);

static async Task<int> DownloadReadmesWithGettingStarted(int count)
{
    using var http = new HttpClient();

    Console.Write("Enter GitHub token (leave empty for unauthenticated access): ");
    string token = Console.ReadLine()?.Trim() ?? "";

    if (!string.IsNullOrEmpty(token))
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("token", token);

    http.DefaultRequestHeaders.UserAgent.ParseAdd("DotnetReadmeFetcher");

    int saved = 0;
    int page = 1;

    while (saved < count)
    {
        string query =
            $"https://api.github.com/search/repositories?" +
            $"q=language:C%23+stars:>10&sort=stars&order=desc&page={page}&per_page=30";

        HttpResponseMessage searchResponse = await http.GetAsync(query);
        if (!searchResponse.IsSuccessStatusCode)
        {
            Console.WriteLine($"GitHub search failed: {searchResponse.StatusCode}");
            return 0;
        }

        var searchResult = System.Text.Json.JsonDocument.Parse(await searchResponse.Content.ReadAsStringAsync());
        var items = searchResult.RootElement.GetProperty("items");

        foreach (var repo in items.EnumerateArray())
        {
            string owner = repo.GetProperty("owner").GetProperty("login").GetString() ?? "";
            string name = repo.GetProperty("name").GetString() ?? "";
            string readmeUrl = $"https://api.github.com/repos/{owner}/{name}/readme";

            var rawContent = string.Empty;
            bool downloadSucceeded = false;

            while (!downloadSucceeded)
            {

                try
                {
                    var request = new HttpRequestMessage(HttpMethod.Get, readmeUrl);
                    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github.v3.raw"));
                    request.Headers.UserAgent.ParseAdd("DotnetReadmeFetcher");

                    var response = await http.SendAsync(request);
                    downloadSucceeded = response.IsSuccessStatusCode;

                    if (!response.IsSuccessStatusCode)
                    {
                        Console.WriteLine($"Failed to fetch readme for {owner}/{name}: {response.StatusCode}");
                    }

                    rawContent = await response.Content.ReadAsStringAsync();
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"Error downloading README from {owner}/{name}: {ex.Message}");
                }

                if (!downloadSucceeded)
                {
                    Console.Write("Retry, skip, or quit? (r/s/q): ");
                    string? input = Console.ReadLine()?.Trim().ToLower();
                    if (input == "q")
                    {
                        Console.WriteLine("Aborting download process.");
                        return saved;
                    }
                    else if (input != "r")
                    {
                        break; // skip to next repo
                    }
                }

            }

            if (!downloadSucceeded) continue;

            var lines = rawContent.Replace("\r", "").Split('\n');
            bool hasGettingStarted = lines.Any(line =>
                line.TrimStart().StartsWith('#') &&
                line.Contains("getting started", StringComparison.InvariantCultureIgnoreCase));

            if (!hasGettingStarted) continue;

            string fileName = $"{owner}_{name}_readme.md";
            foreach (char c in Path.GetInvalidFileNameChars())
                fileName = fileName.Replace(c, '_');

            await File.WriteAllTextAsync(fileName, rawContent);
            Console.WriteLine($"Saved: {fileName}");

            if (++saved >= count) break;
        }

        page++;
    }

    return saved;
}