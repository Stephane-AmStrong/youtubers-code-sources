public class Markdown(string content)
{
    private string[] _content =
        content.Split(new[] { '\r', '\n' }).Select(line => line.Trim('\r', '\n')).ToArray();

    public IEnumerable<string> Lines => _content;

    public IEnumerable<(int level, string title)> GetHeadings()
    {
        foreach (var line in _content)
        {
            if (line.TrimStart().StartsWith("#"))
            {
                int level = line.TrimStart().TakeWhile(c => c == '#').Count();
                string title = line.Substring(level).Trim();
                yield return (level, title);
            }
        }
    }

    public bool ContainsSection(string titlePart) =>
        this.GetHeadings().Any(Contains(titlePart));

    private Func<(int level, string title), bool> Contains(string titlePart) =>
        heading => heading.title.Contains(titlePart, StringComparison.InvariantCultureIgnoreCase);

    public async Task SaveAsync(string path) =>
        await File.WriteAllLinesAsync(path, this.Lines);
}