using System.Net.Http.Headers;

public class GitHubApiClient
{
    private HttpClient _http;

    public GitHubApiClient()
    {
        _http = new();
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("DotnetReadmeFetcher");
    }

    public GitHubApiClient(string token) : this()
    {
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("token", token);
    }

    private Uri GetQueryReposUrl(int page) =>
        new Uri($"https://api.github.com/search/repositories?" +
                $"q=language:C%23+stars:>10&sort=stars&order=desc&page={page}&per_page=30");
    
    private Uri GetRepoReadmeUrl(string owner, string repoName) =>
        new Uri($"https://api.github.com/repos/{owner}/{repoName}/readme");
    
    public async IAsyncEnumerable<(string owner, string repoName)> QueryRepos()
    {
        int page = 1;
        while (true)
        {
            var url = GetQueryReposUrl(page++);
            var response = _http.GetAsync(url).Result;
            if (!response.IsSuccessStatusCode) throw new Exception($"Failed to fetch repos: {response.StatusCode}");

            var result = System.Text.Json.JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var items = result.RootElement.GetProperty("items");

            foreach (var repo in items.EnumerateArray())
            {
                string owner = repo.GetProperty("owner").GetProperty("login").GetString() ?? "";
                string repoName = repo.GetProperty("name").GetString() ?? "";
                yield return (owner, repoName);
            }
        }
    }

    public async Task<Markdown?> GetReadme(string owner, string repoName)
    {
        var url = GetRepoReadmeUrl(owner, repoName);
        var request = new HttpRequestMessage(HttpMethod.Get, url);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github.v3.raw"));
        request.Headers.UserAgent.ParseAdd("DotnetReadmeFetcher");

        var response = await _http.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;

        var rawContent = await response.Content.ReadAsStringAsync();
        return new Markdown(rawContent);
    }
}