﻿await DownloadReadmesWithGettingStarted(5, "C:\\Files");

static async Task<int> DownloadReadmesWithGettingStarted(int count, string destDir)
{
    Directory.CreateDirectory(destDir);

    Console.Write("Enter GitHub token (leave empty for unauthenticated access): ");
    string token = Console.ReadLine() ?? string.Empty;

    var client = string.IsNullOrEmpty(token) ? new GitHubApiClient() : new GitHubApiClient(token);

    int saved = 0;

    try
    {
        await foreach (var (owner, repo) in client.QueryRepos())
        {
            var (flow, fileName) = await ProcessRepo(client, destDir, owner, repo);
            while (flow == Flow.Retry)
            {
                (flow, fileName) = await ProcessRepo(client, destDir, owner, repo);
            }

            if (flow == Flow.Skip) continue;

            if (flow == Flow.Abort)
            {
                Console.WriteLine("Aborting download process.");
                break;
            }

            Console.WriteLine($"Saved: {fileName}");
            if (++saved >= count) break;
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error downloading data: {ex.Message}");
    }

    return saved;
}

static async Task<(Flow flow, string savedFile)> ProcessRepo(GitHubApiClient client, string filesDir, string owner, string repoName)
{
    try
    {
        var readme = await client.GetReadme(owner, repoName);

        if (readme is not null && readme.ContainsSection("getting started"))
        {
            var fileName = FileNameFor(owner, repoName);
            var filePath = Path.Combine(filesDir, fileName);
            await readme.SaveAsync(filePath);
            return (Flow.Continue, fileName);
        }

        return (Flow.Skip, string.Empty);     
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex);
        var flow = OnError($"Error fetching README for {owner}/{repoName}: {ex.Message}");
        return (flow, string.Empty);
    }
}

static Flow OnError(string message)
{
    Console.WriteLine(message);

    Console.Write("Retry, skip, or quit? (r/s/q): ");
    string input = Console.ReadLine()?.Trim().ToLower() ?? string.Empty;

    return input switch
    {
        "q" => Flow.Abort,
        "r" => Flow.Retry,
        _ => Flow.Skip
    };
}

static string FileNameFor(string owner, string repo) =>
    Path.GetInvalidFileNameChars()
        .Aggregate($"{owner}_{repo}_readme.md", (path, invalid) => path.Replace(invalid, '_'));

enum Flow { Continue, Retry, Skip, Abort };
