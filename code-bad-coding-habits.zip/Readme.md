# Source Code Bundle

This package contains the initial and final code for the video [5 Habits I Had To Give Up To Become a Better Programmer](https://youtu.be/84V1xd_kRbQ).

The demo requires .NET 9 SDK.
