# Source Code Bundle

This package contains the initial and final code for the video [There Has Always Been Something Unholy About Exceptions](https://youtu.be/tClRlyzY8SM).

The demo requires .NET 9 SDK.
