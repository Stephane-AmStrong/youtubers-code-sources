using DemoApi.Rules;
using System.Globalization;
using DemoApi.Data;
using DemoApi.Data.Queries;
using DemoApi.Endpoints.Requests;
using DemoApi.Endpoints.Responses;
using DemoApi.Models;
using DemoApi.Models.Editions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DemoApi.Endpoints;

static class BooksHandlers
{
    public static RouteGroupBuilder MapBooks(this RouteGroupBuilder routes)
    {
        routes.MapGet("/books", GetBooks);
        routes.MapGet("/books/{handle}", GetBook).WithName(UriHelper.QuerySingleBookRouteName);
        routes.MapPost("/books", PostBook);
        return routes;
    }

    public static async Task<IResult> GetBooks(BookstoreDbContext dbContext, UriHelper uriHelper,
                                               [FromQuery] string? culture) =>
        Results.Json((await dbContext.Books.QueryAggregates()
            .WithOptionalCultureName(culture)
            .ToListAsync())
            .Select(book => book.ToResponse(uriHelper)));

    public static async Task<IResult> GetBook(BookstoreDbContext dbContext, UriHelper uriHelper, [FromRoute] string handle) =>
        await dbContext.Books.QueryAggregates().WithKey(handle).FirstOrDefaultAsync() is Book book
            ? Results.Json(book.ToResponse(uriHelper))
            :  Results.NotFound();

    public static async Task<IResult> PostBook(BookstoreDbContext dbContext, UriHelper uriHelper,
                             BookTitleToSlug titleToSlug, [FromBody] PostBookRequest book,
                             ITitleValidity titleValidityRule)
    {
        ValidationErrorResponse validationErrors = new(uriHelper.FormatDocumentationUrl<PostBookRequest>());

        Publisher? publisher = null;
        if (string.IsNullOrWhiteSpace(book.PublisherHandle))
        {
            validationErrors.AddFieldValidationError(nameof(book.PublisherHandle), "Publisher is required");
        }
        else
        {
            publisher = await dbContext.Publishers.TryFindByKey(book.PublisherHandle);
            if (publisher is null) validationErrors.AddFieldValidationError(nameof(book.PublisherHandle), "Publisher not found");
        } 

        List<Author> authors = new();
        IEnumerable<string> authorHandles = [];
        if (book.AuthorHandles is null) validationErrors.AddFieldValidationError(nameof(book.AuthorHandles), "Missing author handles");
        else authorHandles = book.AuthorHandles;

        foreach (var authorHandle in authorHandles.Select((handle, index) => (handle, index)))
        {
            Author? author = await dbContext.Authors.TryFindByKey(authorHandle.handle);
            if (author is null) validationErrors.AddFieldValidationError(nameof(book.AuthorHandles), $"Author #{authorHandle.index + 1} not found");
            else authors.Add(author);
        }

        string title = book.Title ?? string.Empty;
        if (string.IsNullOrEmpty(title))
        {
            validationErrors.AddFieldValidationError(nameof(book.Title), $"Invalid title");
        }

        CultureInfo? culture = default;
        try
        {
            if (string.IsNullOrWhiteSpace(book.Culture)) validationErrors.AddFieldValidationError(nameof(book.Culture), "Culture is required");
            else culture = CultureInfo.GetCultureInfo(book.Culture);
        }
        catch (CultureNotFoundException)
        {
            validationErrors.AddFieldValidationError(nameof(book.Culture), "Culture not found");
        }

        CultureInfo? titleCulture = default;
        try
        {
            if (string.IsNullOrWhiteSpace(book.TitleCulture)) validationErrors.AddFieldValidationError(nameof(book.TitleCulture), "Title culture is required");
            else titleCulture = CultureInfo.GetCultureInfo(book.TitleCulture);
        }
        catch (CultureNotFoundException)
        {
            validationErrors.AddFieldValidationError(nameof(book.TitleCulture), "Title culture not found");
        }

        string? handle = null;
        
        if (culture is not null)
        {
            handle = await dbContext.Books.TryGetUniqueHandle(titleToSlug, culture, title, book.Handle);
            if (handle is null) validationErrors.AddFieldValidationError(nameof(book.Handle), "Handle is already in use");
        }

        if (book.PublishedOn is null) validationErrors.AddFieldValidationError(nameof(book.PublishedOn), "Publishing date is required");

        if (validationErrors.ContainsErrors()) return Results.BadRequest(validationErrors);

        IEdition edition = new OrdinalEdition(book.Edition);
        PublicationInfo pub = new Published(new FullDate(book.PublishedOn ?? throw new InvalidOperationException()));
        Release release = new(publisher ?? throw new InvalidOperationException(), edition, pub);

        Book newBook = Book.CreateNew(title, titleCulture?.Name ?? throw new InvalidOperationException(),
                                      culture?.Name ?? throw new InvalidOperationException(),
                                      book.Isbn, authors, release,
                                      handle ?? throw new InvalidOperationException());

        dbContext.Books.Add(newBook);
        await dbContext.SaveChangesAsync();

        return Results.Created(
            uriHelper.FormatBookUrl(newBook).AbsoluteUri,
            newBook.ToResponse(uriHelper));
    }
}
