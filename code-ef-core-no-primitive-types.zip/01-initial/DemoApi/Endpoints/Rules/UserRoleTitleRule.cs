﻿using System.Security.Claims;
using DemoApi.Models;
using DemoApi.Rules;

namespace DemoApi.Endpoints.Rules;

public class UserRoleTitleRule(Func<ClaimsPrincipal> getUser, string role) : ITitleValidity
{
    public bool IsSatisfiedBy(string title) =>
        getUser().IsInRole(role);

    public string ApplyTo(string title) =>
        title;
}

