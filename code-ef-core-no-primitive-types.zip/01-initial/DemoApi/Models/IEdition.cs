﻿namespace DemoApi.Models;

public interface IEdition
{
    IEdition AdvanceToNext();
}
