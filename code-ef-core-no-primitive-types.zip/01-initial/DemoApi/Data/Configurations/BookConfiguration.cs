using DemoApi.Data.Common;
using DemoApi.Data.Converters;
using DemoApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoApi.Data.Configurations;

class BookConfiguration : IEntityTypeConfiguration<Book>
{
    public void Configure(EntityTypeBuilder<Book> entityBuilder)
    {
        entityBuilder.ToTable("Books");

        entityBuilder.Ignore(book => book.Authors);

        entityBuilder.ComplexProperty(book => book.Release).Configure(new ReleaseConfiguration());

        entityBuilder.HasOne(book => book.Publisher).WithMany().HasForeignKey("PublisherId");

        entityBuilder.HasIndex(book => book.Key).IsUnique();
    }
}
