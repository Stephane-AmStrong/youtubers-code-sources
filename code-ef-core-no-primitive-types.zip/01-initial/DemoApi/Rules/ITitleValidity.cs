using DemoApi.Models;

namespace DemoApi.Rules;

public interface ITitleValidity
{
    bool IsSatisfiedBy(string title);
    string ApplyTo(string title);
}