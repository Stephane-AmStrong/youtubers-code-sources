﻿using DemoApi.Models;

namespace DemoApi.Rules;

public class AllTitleValidity(params ITitleValidity[] rules) : ITitleValidity
{
    public bool IsSatisfiedBy(string title) =>
        rules.All(rule => rule.IsSatisfiedBy(title));

    public string ApplyTo(string title) =>
        rules.Aggregate(title, (result, rule) => rule.ApplyTo(result));
}

