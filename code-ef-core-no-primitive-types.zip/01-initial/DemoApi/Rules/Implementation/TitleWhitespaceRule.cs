using DemoApi.Models;

namespace DemoApi.Rules.Implementation;

public class TitleWhitespaceRule : ITitleValidity
{
    public bool IsSatisfiedBy(string title) =>
        !title.StartsWith(' ') && !title.EndsWith(' ') &&
        !title.Contains('\t') && !title.Contains("  ");
    
    public string ApplyTo(string title) =>
        IsSatisfiedBy(title) ? title : Fix(title);

    private string Fix(string value) =>
        string.Join(" ", value.Replace('\t', ' ').Split(' ', StringSplitOptions.RemoveEmptyEntries));
}