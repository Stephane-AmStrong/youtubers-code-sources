﻿using DemoApi.Models;

namespace DemoApi.Rules.Implementation;

public class NonEmptyTitleRule : ITitleValidity
{
    public bool IsSatisfiedBy(string title) =>
        !string.IsNullOrWhiteSpace(title);

    public string ApplyTo(string title) =>
        IsSatisfiedBy(title) ? title : new(string.Empty);
}

