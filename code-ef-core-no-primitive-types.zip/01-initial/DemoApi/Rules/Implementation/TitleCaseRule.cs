﻿using DemoApi.Models;

namespace DemoApi.Rules.Implementation;

public class TitleCaseRule : ITitleValidity
{
    public bool IsSatisfiedBy(string title) => true;         // TBD

    public string ApplyTo(string title) => title;         // TBD
}

public enum TitleCaseStyle
{
    AmericanPsychologicalAssociation,
    AmericanMedicalAssociation,
    AssociatedPress,
    ChicagoManualOfStyle,
    ModernLanguageAssociation,
    NewYorkTimes,
}