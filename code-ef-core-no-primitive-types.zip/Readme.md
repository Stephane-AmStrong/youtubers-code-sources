# Source Code Bundle

This package contains the initial and final code for the video [Stop Blaming EF Core for Your Anemic Models – Here’s How to Fix Them](https://youtu.be/TZsdT7Pf98I).

The demo requires .NET 8 SDK and uses Entity Framework Core with SqlServer (or LocalDb). Please select or set the connection string in `appsettings.Development.json` before running the application.
