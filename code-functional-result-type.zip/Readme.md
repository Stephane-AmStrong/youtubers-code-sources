# Source Code Bundle

This package contains the initial and final code for the video [From Procedural to Functional: Building a Monadic Result Type](https://youtu.be/8uoifFX1I3U).

The demo requires .NET 8 SDK and uses Entity Framework Core with SqlServer (or LocalDb). Please select or set the connection string in `appsettings.Development.json` before running the application.
